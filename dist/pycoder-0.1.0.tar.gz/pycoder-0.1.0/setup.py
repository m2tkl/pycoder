# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pycoder', 'pycoder.tests', 'pycoder.tests.auth', 'pycoder.tests.scrape']

package_data = \
{'': ['*'], 'pycoder.tests.auth': ['source/*']}

install_requires = \
['beautifulsoup4>=4.9.3,<5.0.0',
 'fire>=0.4.0,<0.5.0',
 'html5lib>=1.1,<2.0',
 'requests>=2.25.1,<3.0.0']

entry_points = \
{'console_scripts': ['pc = pycoder.main:main']}

setup_kwargs = {
    'name': 'pycoder',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'm2tkl',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
